<?php
$str_button      = 'scriptcase9_SweetAmour';
$str_chart_theme = '';
$str_grid_header_bg = "";
$str_google_fonts = "";
$str_toolbar_separator = 'scriptcase__NM__btn__NM__scriptcase9_Rhino__NM__nm_scriptcase9_Rhino_pipe.png';
$pagina_schemamenu = 'scriptcase/default';
$index_class_pos = '';
$index_class_neg = '';
$index_class_neu = '';
$bg_line_degrade = array();
$bg_line_degrade[0] = '';
$bg_line_degrade[1] = '';
$bg_line_degrade[2] = '';
$bg_line_degrade[3] = '';
$str_arrow_up = 'scriptcase__NM__arrow_out_new.gif';
$str_arrow_down = 'scriptcase__NM__arrow_in_new.gif';
$str_menu_bar_background_color = '#FFFFFF';
$str_menu_sel_background_color = '#FFFFFF';
$str_item_bar_background_color = '#FFFFFF';
$str_item_bar_border_color = '#455c72';
$str_item_sel_background_color = '#F3F7FB';
$str_pagina_icon_bg = '';
$breadcrumbline_separator = 'scriptcase__NM__btn__NM__scriptcase9_Rhino__NM__nm_scriptcase9_Rhino_breadcrumb.png';
$expand_icon = 'scriptcase__NM__icon_expand.png';
$collapse_icon = 'scriptcase__NM__icon_expand.png';
?>