<?php
$str_button      = 'scriptcase9_Rhino';
$str_chart_theme = '';
$str_grid_header_bg = "";
$str_google_fonts = "";
$str_tab_space = '1px';
$index_class_pos = '';
$index_class_neg = '';
$index_class_neu = '';
$str_toolbar_separator = 'scriptcase__NM__btn__NM__scriptcase9_Rhino__NM__nm_scriptcase9_Rhino_pipe.png';
?>