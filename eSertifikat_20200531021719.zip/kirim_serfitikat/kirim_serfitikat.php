<?php 
  include_once('../kirim_serfitikat/index.php'); 
?> 
