<?php
   Header('Location: index.php');
?>
