<?php 
  include_once('../cetak_sertifikat/index.php'); 
?> 
